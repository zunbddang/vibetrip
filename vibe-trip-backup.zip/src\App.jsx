import React, { useState, useMemo, useEffect, useRef } from 'react';
import {
  GoogleMap,
  useJsApiLoader,
  Marker,
  InfoWindow,
  Autocomplete
} from '@react-google-maps/api';
import { Home, Map as MapIcon, Image as ImageIcon, PlusSquare, Heart, MessageCircle, Bookmark, Download, MapPin, Share2, TableProperties, LocateFixed, Search } from 'lucide-react';
import './index.css';

// Initial Trip Data
const INITIAL_SPOTS = [
  { id: 1, day: 1, date: "2026-06-15", name: "Charles de Gaulle Airport", lat: 49.0097, lng: 2.5479, type: "itinerary", memo: "Arrival at 10:00 AM. Get Navigo pass." },
  { id: 2, day: 1, date: "2026-06-15", name: "Le Relais de l'Entrecôte", lat: 48.8661, lng: 2.3078, type: "food", memo: "Famous steak frites. No reservation, queue early!" },
  { id: 3, day: 1, date: "2026-06-15", name: "Eiffel Tower", lat: 48.8584, lng: 2.2945, type: "itinerary", memo: "Sunset view is essential. Bring champagne." },
  { id: 4, day: 2, date: "2026-06-16", name: "Louvre Museum", lat: 48.8606, lng: 2.3376, type: "itinerary", memo: "Pre-booked entry at 09:30." },
  { id: 5, day: 2, date: "2026-06-16", name: "Angelina Paris", lat: 48.8647, lng: 2.3283, type: "food", memo: "Signature hot chocolate 'L'Africain' is a must." }
];

const GALLERY_DATA = [
  { id: 1, url: "https://images.unsplash.com/photo-1502602898657-3e91760cbb34?auto=format&fit=crop&w=400&q=80", user: "Dad" },
  { id: 2, url: "https://images.unsplash.com/photo-1549144511-f099e773c147?auto=format&fit=crop&w=400&q=80", user: "Mom" },
  { id: 3, url: "https://images.unsplash.com/photo-1431274172761-fca41d93e114?auto=format&fit=crop&w=400&q=80", user: "Sister" },
  { id: 4, url: "https://images.unsplash.com/photo-1511739001486-6bfe10ce785f?auto=format&fit=crop&w=400&q=80", user: "Dad" },
  { id: 5, url: "https://images.unsplash.com/photo-1503917988258-f19178c1ef5b?auto=format&fit=crop&w=400&q=80", user: "Brother" },
  { id: 6, url: "https://images.unsplash.com/photo-1499856871958-5b9627545d1a?auto=format&fit=crop&w=400&q=80", user: "Mom" }
];

const App = () => {
  const [activeTab, setActiveTab] = useState('feed'); // feed, map, gallery, table
  const [tripSpots, setTripSpots] = useState(INITIAL_SPOTS);
  const [selectedSpot, setSelectedSpot] = useState(null);
  const [searchedPlace, setSearchedPlace] = useState(null);
  const [shareStatus, setShareStatus] = useState(false);
  const [userLocation, setUserLocation] = useState(null);
  const [map, setMap] = useState(null);
  const mapSearchRef = useRef(null);

  const handleShare = () => {
    const url = window.location.href;
    navigator.clipboard.writeText(url).then(() => {
      setShareStatus(true);
      setTimeout(() => setShareStatus(false), 2000);
    });
  };

  useEffect(() => {
    if ("geolocation" in navigator) {
      const watchId = navigator.geolocation.watchPosition(
        (position) => {
          setUserLocation({
            lat: position.coords.latitude,
            lng: position.coords.longitude,
          });
        },
        (error) => console.error("Error tracking location:", error),
        { enableHighAccuracy: true }
      );
      return () => navigator.geolocation.clearWatch(watchId);
    }
  }, []);

  const handleCenterOnMe = () => {
    if (userLocation && map) {
      map.panTo(userLocation);
      map.setZoom(15);
    }
  };

  const { isLoaded } = useJsApiLoader({
    id: 'google-map-script',
    googleMapsApiKey: import.meta.env.VITE_GOOGLE_MAPS_API_KEY,
    libraries: ["places"],
    language: "ko"
  });

  const onMapSearchLoad = (autocomplete) => {
    mapSearchRef.current = autocomplete;
  };

  const onMapPlaceChanged = () => {
    if (mapSearchRef.current !== null) {
      const place = mapSearchRef.current.getPlace();
      if (place.geometry) {
        const newPlace = {
          id: 'temp-' + Date.now(),
          name: place.name,
          lat: place.geometry.location.lat(),
          lng: place.geometry.location.lng(),
          type: "itinerary",
          memo: place.formatted_address,
          day: tripSpots.length > 0 ? tripSpots[tripSpots.length - 1].day : 1,
          date: tripSpots.length > 0 ? tripSpots[tripSpots.length - 1].date : new Date().toISOString().split('T')[0]
        };
        setSearchedPlace(newPlace);
        setSelectedSpot(newPlace); // Automatically open InfoWindow
        if (map) {
          map.panTo({ lat: newPlace.lat, lng: newPlace.lng });
          map.setZoom(15);
        }
      }
    }
  };

  const handleUpdateSpot = (id, field, value) => {
    setTripSpots(prev => prev.map(spot => spot.id === id ? { ...spot, [field]: value } : spot));
  };

  const handleAddRow = () => {
    const lastSpot = tripSpots[tripSpots.length - 1];
    const newSpot = {
      id: Date.now(),
      day: lastSpot ? lastSpot.day : 1,
      date: lastSpot ? lastSpot.date : new Date().toISOString().split('T')[0],
      name: "새 장소",
      lat: lastSpot ? lastSpot.lat : 48.8566,
      lng: lastSpot ? lastSpot.lng : 2.3522,
      type: "itinerary",
      memo: ""
    };
    setTripSpots(prev => [...prev, newSpot]);
  };

  const handleDeleteRow = (id) => {
    setTripSpots(prev => prev.filter(spot => spot.id !== id));
  };

  const groupSpotsByDay = useMemo(() => {
    const groups = {};
    tripSpots.forEach(spot => {
      if (!groups[spot.day]) groups[spot.day] = { day: spot.day, date: spot.date, spots: [] };
      groups[spot.day].spots.push(spot);
    });
    return Object.values(groups);
  }, [tripSpots]);

  const center = { lat: 48.8566, lng: 2.3522 }; // Paris center

  return (
    <div className="app-container">
      <header className="app-header">
        <h1 className="logo">VibeTrip ✨</h1>
        <button className={`share-icon-btn ${shareStatus ? 'shared' : ''}`} onClick={handleShare}>
          <Share2 size={20} />
          {shareStatus && <span className="share-toast">Link Copied!</span>}
        </button>
      </header>

      <main style={{ flex: 1, overflowY: 'auto' }}>
        {activeTab === 'feed' && (
          <div className="feed-container fade-in">
            {groupSpotsByDay.map((dayData) => (
              <div key={dayData.day}>
                <div className="date-badge">Day {dayData.day} • {dayData.date}</div>
                {dayData.spots.map((spot) => (
                  <div key={spot.id} className="post-card">
                    <div className="post-header">
                      <div className="post-avatar">{spot.id}</div>
                      <div className="post-username">{spot.name}</div>
                    </div>
                    <div className="post-image" style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', background: '#f5f5f5' }}>
                      <MapPin size={48} color="#ccc" />
                    </div>
                    <div className="post-actions">
                      <Heart size={24} />
                      <MessageCircle size={24} />
                      <Bookmark size={24} style={{ marginLeft: 'auto' }} />
                    </div>
                    <div className="post-caption">
                      <span className="type-tag tag">{spot.type === 'food' ? '🍴 맛집' : '📍 일정'}</span>
                      <div className="memo-box">{spot.memo}</div>
                    </div>
                  </div>
                ))}
              </div>
            ))}
          </div>
        )}

        {activeTab === 'map' && isLoaded && (
          <div className="map-view-container fade-in">
            <div className="map-search-overlay">
              <Autocomplete onLoad={onMapSearchLoad} onPlaceChanged={onMapPlaceChanged}>
                <div className="map-search-box">
                  <Search size={18} color="#8e8e8e" />
                  <input type="text" placeholder="장소 검색 및 일정 추가..." className="map-search-input" />
                </div>
              </Autocomplete>
            </div>
            <GoogleMap
              mapContainerStyle={{ width: '100%', height: '100%' }}
              center={center}
              zoom={12}
              onLoad={m => setMap(m)}
              options={{ disableDefaultUI: true, zoomControl: true }}
            >
              {tripSpots.map((spot, idx) => (
                <Marker
                  key={spot.id}
                  position={{ lat: spot.lat, lng: spot.lng }}
                  label={{
                    text: String(idx + 1),
                    color: "white",
                    fontWeight: "bold"
                  }}
                  onClick={() => {
                    setSelectedSpot(spot);
                    setSearchedPlace(null);
                  }}
                />
              ))}

              {searchedPlace && (
                <Marker
                  position={{ lat: searchedPlace.lat, lng: searchedPlace.lng }}
                  icon="http://maps.google.com/mapfiles/ms/icons/red-pushpin.png"
                  onClick={() => setSelectedSpot(searchedPlace)}
                />
              )}

              {userLocation && window.google && (
                <Marker
                  position={userLocation}
                  icon={{
                    path: window.google.maps.SymbolPath.CIRCLE,
                    fillColor: "#4285F4",
                    fillOpacity: 1,
                    strokeColor: "white",
                    strokeWeight: 2,
                    scale: 8,
                  }}
                  title="My Location"
                />
              )}

              {selectedSpot && (
                <InfoWindow
                  position={{ lat: selectedSpot.lat, lng: selectedSpot.lng }}
                  onCloseClick={() => setSelectedSpot(null)}
                >
                  <div style={{ padding: '5px' }}>
                    <h4 style={{ margin: '0 0 5px 0' }}>{selectedSpot.name}</h4>
                    <p style={{ margin: 0, fontSize: '11px', color: '#666', maxWidth: '150px' }}>{selectedSpot.memo}</p>
                    {String(selectedSpot.id).startsWith('temp-') ? (
                      <button className="add-to-trip-mini" onClick={() => {
                        setTripSpots(prev => [...prev, { ...selectedSpot, id: Date.now() }]);
                        setSelectedSpot(null);
                        setSearchedPlace(null);
                      }}>일정에 추가</button>
                    ) : (
                      <div className="already-added">이미 추가된 장소</div>
                    )}
                  </div>
                </InfoWindow>
              )}
            </GoogleMap>
            <button className="locate-btn" onClick={handleCenterOnMe}>
              <LocateFixed size={20} />
            </button>
          </div>
        )}

        {activeTab === 'gallery' && (
          <div className="gallery-grid fade-in">
            {GALLERY_DATA.map((img) => (
              <div key={img.id} className="gallery-item">
                <img src={img.url} alt={`Trip ${img.id}`} />
                <button
                  style={{ position: 'absolute', bottom: 8, right: 8, color: 'white', background: 'rgba(0,0,0,0.4)', border: 'none', borderRadius: '4px', padding: '4px' }}
                  onClick={() => window.open(img.url, '_blank')}
                >
                  <Download size={16} />
                </button>
              </div>
            ))}
          </div>
        )}

        {activeTab === 'table' && (
          <div className="table-view-container fade-in">
            <div className="spreadsheet-header">
              <h3>여행 일정 관리</h3>
              <button className="add-row-btn" onClick={handleAddRow}>
                <PlusSquare size={16} /> 일정 추가
              </button>
            </div>
            <div className="spreadsheet-wrapper">
              <table className="spreadsheet-table">
                <thead>
                  <tr>
                    <th style={{ width: '60px' }}>일차</th>
                    <th style={{ width: '120px' }}>날짜</th>
                    <th style={{ width: '100px' }}>분류</th>
                    <th>장소명</th>
                    <th>상세 메모</th>
                    <th style={{ width: '40px' }}></th>
                  </tr>
                </thead>
                <tbody>
                  {tripSpots.map((spot) => (
                    <tr key={spot.id}>
                      <td className="center">
                        <input
                          type="number"
                          className="sheet-input center"
                          value={spot.day}
                          onChange={(e) => handleUpdateSpot(spot.id, 'day', parseInt(e.target.value) || 1)}
                        />
                      </td>
                      <td>
                        <input
                          type="date"
                          className="sheet-input"
                          value={spot.date}
                          onChange={(e) => handleUpdateSpot(spot.id, 'date', e.target.value)}
                        />
                      </td>
                      <td>
                        <select
                          className="sheet-select"
                          value={spot.type}
                          onChange={(e) => handleUpdateSpot(spot.id, 'type', e.target.value)}
                        >
                          <option value="itinerary">일정 📍</option>
                          <option value="food">맛집 🍴</option>
                        </select>
                      </td>
                      <td>
                        <input
                          type="text"
                          className="sheet-input strong"
                          value={spot.name}
                          onChange={(e) => handleUpdateSpot(spot.id, 'name', e.target.value)}
                          placeholder="장소명 입력"
                        />
                      </td>
                      <td className="memo-cell">
                        <textarea
                          className="sheet-textarea"
                          value={spot.memo}
                          onChange={(e) => handleUpdateSpot(spot.id, 'memo', e.target.value)}
                          placeholder="메모를 입력하세요..."
                        />
                      </td>
                      <td className="center">
                        <button className="delete-row-btn" onClick={() => handleDeleteRow(spot.id)}>×</button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}
      </main>

      <nav className="bottom-nav">
        <button className={`nav-item ${activeTab === 'feed' ? 'active' : ''}`} onClick={() => setActiveTab('feed')}>
          <Home size={24} />
          <span>Feed</span>
        </button>
        <button className={`nav-item ${activeTab === 'table' ? 'active' : ''}`} onClick={() => setActiveTab('table')}>
          <TableProperties size={24} />
          <span>Sheet</span>
        </button>
        <button className={`nav-item ${activeTab === 'map' ? 'active' : ''}`} onClick={() => setActiveTab('map')}>
          <MapIcon size={24} />
          <span>Map</span>
        </button>
        <button className={`nav-item ${activeTab === 'gallery' ? 'active' : ''}`} onClick={() => setActiveTab('gallery')}>
          <ImageIcon size={24} />
          <span>Album</span>
        </button>
      </nav>
    </div>
  );
};

export default App;
